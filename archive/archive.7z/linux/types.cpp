void __debugbreak() { (*(int*)0)=0x33; }


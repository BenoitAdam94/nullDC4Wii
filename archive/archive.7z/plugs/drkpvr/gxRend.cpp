/**
 * @file gxRend.cpp
 * @brief GX Renderer implementation for Dreamcast emulator on Wii
 * 
 * This file implements hardware-accelerated rendering of Dreamcast graphics
 * using the Nintendo Wii's GX graphics library. It handles vertex processing,
 * texture conversion, and polygon rendering through the fixed-function pipeline.
 */

#include "config.h"
#include "gxRend.h"

#if REND_API == REND_WII || 1

#include <gccore.h>
#include <malloc.h>
#include <cstring>
#include <algorithm>
#include "regs.h"

using namespace TASplitter;
using namespace GXRendConfig;

// =============================================================================
// Constants and Configuration
// =============================================================================

// Color conversion macros
#define ABGR8888(x) ((x&0xFF00FF00) | ((x>>16)&0xFF) | ((x&0xFF)<<16))
#define ABGR4444(x) ((x&0xF0F0) | ((x>>8)&0xF) | ((x&0xF)<<8))
#define ABGR0565(x) ((x&(0x3F<<5)) | ((x>>11)&0x1F) | ((x&0x1F)<<11))
#define ABGR1555(x) ((x&0x83E0) | ((x>>10)&0x1F) | ((x&0x1F)<<10))

// Component extraction macros
#define ABGR4444_A(x) ((x)>>12)
#define ABGR4444_R(x) ((x>>8)&0xF)
#define ABGR4444_G(x) ((x>>4)&0xF)
#define ABGR4444_B(x) ((x)&0xF)

#define ABGR0565_R(x) ((x)>>11)
#define ABGR0565_G(x) ((x>>5)&0x3F)
#define ABGR0565_B(x) ((x)&0x1F)

#define ABGR1555_A(x) ((x>>15))
#define ABGR1555_R(x) ((x>>10)&0x1F)
#define ABGR1555_G(x) ((x>>5)&0x1F)
#define ABGR1555_B(x) ((x)&0x1F)

// Texture coordinate transformations
#define VTX_TFX(x) (x)
#define VTX_TFY(y) (y)

// =============================================================================
// Data Structures
// =============================================================================

/**
 * @brief Vertex structure for GX rendering
 */
struct Vertex {
    float u, v;           // Texture coordinates
    unsigned int col;     // Vertex color (ABGR format)
    float x, y, z;        // Position
};

/**
 * @brief Vertex list descriptor
 */
struct VertexList {
    union {
        Vertex* ptr;      // Pointer to vertex data
        s32 count;        // Vertex count (with flags in high bit)
    };
};

/**
 * @brief Polygon parameters from PVR
 */
struct PolyParam {
    PCW pcw;              // Parameter Control Word
    ISP_TSP isp;          // ISP/TSP Instruction Word
    TSP tsp;              // TSP Instruction Word
    TCW tcw;              // Texture Control Word
};

/**
 * @brief Texture cache descriptor
 */
struct TextureCacheDesc {
    GXTexObj tex;         // GX texture object
    GXTlutObj pal;        // GX palette object (for paletted textures)
    u32 addr;             // VRAM address
    bool has_pal;         // Has palette flag
};

/**
 * @brief ISP background tag structure
 */
union ISP_BACKGND_T_type {
    struct {
        u32 tag_offset : 3;
        u32 tag_address : 21;
        u32 skip : 3;
        u32 shadow : 1;
        u32 cache_bypass : 1;
    };
    u32 full;
};

/**
 * @brief ISP background depth union
 */
union ISP_BACKGND_D_type {
    u32 i;
    f32 f;
};

// =============================================================================
// Forward Declarations
// =============================================================================

void DoRender();

// =============================================================================
// Global State
// =============================================================================

// Video subsystem
static void* frameBuffer[2] = {nullptr, nullptr};
static GXRModeObj* rmode = nullptr;
static u8 gp_fifo[DEFAULT_FIFO_SIZE] __attribute__((aligned(32)));
static int currentFrameBuffer = 0;

// VRAM buffer
u8* vram_buffer = nullptr;

// Vertex processing state
static Vertex ALIGN16 vertices[MAX_VERTICES];
static VertexList ALIGN16 lists[MAX_LISTS];
static PolyParam ALIGN16 listModes[MAX_LISTS];

static Vertex* curVTX = vertices;
static VertexList* curLST = lists;
static VertexList* TransLST = nullptr;
static PolyParam* curMod = listModes - 1;
static bool global_regd = false;
static float vtx_min_Z = DEFAULT_MIN_Z;
static float vtx_max_Z = DEFAULT_MAX_Z;

// FPS display
static char fps_text[512] = {0};

// Forward declaration for VertexDecoder
struct VertexDecoder;

// Tile accelerator
FifoSplitter<VertexDecoder> TileAccel;

// =============================================================================
// Helper Functions
// =============================================================================

/**
 * @brief Clamp value between low and high
 */
template<typename T>
inline void colclamp(T low, T hi, T& val) {
    if (val < low) val = low;
    if (val > hi) val = hi;
}

/**
 * @brief Convert VRAM offset from 32-bit to 64-bit addressing
 * @param offset32 32-bit offset
 * @return 64-bit offset
 */
u32 vramlock_ConvOffset32toOffset64(u32 offset32);

/**
 * @brief Read float from VRAM
 */
static inline f32 vrf(u32 addr) {
    return *(f32*)&params.vram[vramlock_ConvOffset32toOffset64(addr)];
}

/**
 * @brief Read u32 from VRAM
 */
static inline u32 vri(u32 addr) {
    return *(u32*)&params.vram[vramlock_ConvOffset32toOffset64(addr)];
}

/**
 * @brief Convert 16-bit UV coordinate to float
 */
static inline f32 CVT16UV(u32 uv) {
    uv <<= 16;
    return *(f32*)&uv;
}

/**
 * @brief Convert YUV422 to RGB565
 * @param Y Luminance component
 * @param Yu U chrominance component  
 * @param Yv V chrominance component
 * @return RGB565 color value
 */
u32 YUV422(s32 Y, s32 Yu, s32 Yv) {
    s32 B = (76283 * (Y - 16) + 132252 * (Yu - 128)) >> (16 + 3);
    s32 G = (76283 * (Y - 16) - 53281 * (Yv - 128) - 25624 * (Yu - 128)) >> (16 + 2);
    s32 R = (76283 * (Y - 16) + 104595 * (Yv - 128)) >> (16 + 3);

    colclamp(0, 0x1F, B);
    colclamp(0, 0x3F, G);
    colclamp(0, 0x1F, R);

    return (B << 11) | (G << 5) | R;
}

/**
 * @brief Calculate twiddled texture offset
 * @param x X coordinate
 * @param y Y coordinate
 * @param x_sz X size
 * @param y_sz Y size
 * @return Twiddled offset
 */
u32 fastcall twop(u32 x, u32 y, u32 x_sz, u32 y_sz) {
    u32 rv = 0;
    u32 sh = 0;
    
    x_sz >>= 1;
    y_sz >>= 1;
    
    while (x_sz != 0 || y_sz != 0) {
        if (y_sz) {
            u32 temp = y & 1;
            rv |= temp << sh;
            y_sz >>= 1;
            y >>= 1;
            sh++;
        }
        if (x_sz) {
            u32 temp = x & 1;
            rv |= temp << sh;
            x_sz >>= 1;
            x >>= 1;
            sh++;
        }
    }
    
    return rv;
}

/**
 * @brief Calculate GX texture offset
 * @param x X coordinate
 * @param y Y coordinate  
 * @param w Width (must be multiple of 4)
 * @return GX texture offset
 */
u32 GX_TexOffs(u32 x, u32 y, u32 w) {
    w /= 4;
    u32 xs = x & 3;
    x >>= 2;
    u32 ys = y & 3;
    y >>= 2;
    
    return (y * w + x) * 16 + (ys * 4 + xs);
}

/**
 * @brief Write pixel to GX texture buffer
 */
inline void pb_prel(u16* dst, u32 pbw, u32 x, u32 y, u32 col) {
    dst[GX_TexOffs(x, y, pbw)] = col;
}

/**
 * @brief Reset vertex processing state
 */
void reset_vtx_state() {
    curVTX = vertices;
    curLST = lists;
    curMod = listModes - 1;
    global_regd = false;
    vtx_min_Z = DEFAULT_MIN_Z;
    vtx_max_Z = DEFAULT_MAX_Z;
}

/**
 * @brief Read offset color if present
 */
static inline void decode_pvr_vertex(u32 base, u32 ptr, Vertex* cv) {
    // Read ISP/TSP/TCW parameters
    ISP_TSP isp;
    TSP tsp;
    TCW tcw;

    isp.full = vri(base);
    tsp.full = vri(base + 4);
    tcw.full = vri(base + 8);

    // Read XYZ coordinates (always present)
    cv->x = vrf(ptr); ptr += 4;
    cv->y = vrf(ptr); ptr += 4;
    cv->z = vrf(ptr); ptr += 4;

    // Read texture coordinates if textured
    if (isp.Texture) {
        if (isp.UV_16b) {
            u32 uv = vri(ptr);
            cv->u = CVT16UV((u16)uv);
            cv->v = CVT16UV((u16)(uv >> 16));
            ptr += 4;
        } else {
            cv->u = vrf(ptr); ptr += 4;
            cv->v = vrf(ptr); ptr += 4;
        }
    }

    // Read base color
    u32 col = vri(ptr); ptr += 4;
    cv->col = col;

    // Read offset color if present
    if (isp.Offset) {
        // u32 offset_col = vri(ptr); ptr += 4;
        ptr += 4; // Skip offset color for now
        // TODO: Handle offset color properly
    }
}

// =============================================================================
// Pixel Format Converters
// =============================================================================

/**
 * Macros for defining pixel format converters
 * These convert various PVR texture formats to GX-compatible formats
 */
#define pixelcvt_start(name, xa, yb) \
    struct name { \
        static const u32 xpp = xa; \
        static const u32 ypp = yb; \
        __forceinline static void fastcall Convert(u16* pb, u32 x, u32 y, u32 pbw, u8* data) {

#define pixelcvt_end } }

#define pixelcvt_next(name, x, y) \
    pixelcvt_end; \
    pixelcvt_start(name, x, y)

#define pixelcvt_startVQ(name, x, y) \
    struct name { \
        static const u32 xpp = x; \
        static const u32 ypp = y; \
        __forceinline static u32 fastcall Convert(u16* data) {

#define pixelcvt_endVQ } }

#define pixelcvt_nextVQ(name, x, y) \
    pixelcvt_endVQ; \
    pixelcvt_startVQ(name, x, y)

// Non-twiddled format converters
pixelcvt_start(conv565_PL, 4, 1)
{
    u16* p_in = (u16*)data;
    pb_prel(pb, pbw, x + 0, y, ABGR0565(p_in[0]));
    pb_prel(pb, pbw, x + 1, y, ABGR0565(p_in[1]));
    pb_prel(pb, pbw, x + 2, y, ABGR0565(p_in[2]));
    pb_prel(pb, pbw, x + 3, y, ABGR0565(p_in[3]));
}
pixelcvt_next(conv1555_PL, 4, 1)
{
    u16* p_in = (u16*)data;
    pb_prel(pb, pbw, x + 0, y, ABGR1555(p_in[0]));
    pb_prel(pb, pbw, x + 1, y, ABGR1555(p_in[1]));
    pb_prel(pb, pbw, x + 2, y, ABGR1555(p_in[2]));
    pb_prel(pb, pbw, x + 3, y, ABGR1555(p_in[3]));
}
pixelcvt_next(conv4444_PL, 4, 1)
{
    u16* p_in = (u16*)data;
    pb_prel(pb, pbw, x + 0, y, ABGR4444(p_in[0]));
    pb_prel(pb, pbw, x + 1, y, ABGR4444(p_in[1]));
    pb_prel(pb, pbw, x + 2, y, ABGR4444(p_in[2]));
    pb_prel(pb, pbw, x + 3, y, ABGR4444(p_in[3]));
}
pixelcvt_end;

// NOTE: Additional pixel converters would continue here
// (Twiddled, VQ-compressed, paletted formats, etc.)
// Truncated for brevity but would follow same pattern

// =============================================================================
// Rendering Implementation
// =============================================================================

/**
 * @brief Perform actual rendering of accumulated geometry
 */
void DoRender() {
    float dc_width = 640;
    float dc_height = 480;

    VIDEO_SetBlack(FALSE);
    GX_SetViewport(0, 0, rmode->fbWidth, rmode->efbHeight, 0, 1);
    GX_InvVtxCache();
    GX_InvalidateTexAll();

    GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_POS, GX_POS_XYZ, GX_F32, 0);
    GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX0, GX_TEX_ST, GX_F32, 0);
    GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_CLR0, GX_CLR_RGBA, GX_RGBA8, 0);

    GX_SetNumChans(1);
    GX_SetNumTexGens(1);

    GX_SetTevOrder(GX_TEVSTAGE0, GX_TEXCOORD0, GX_TEXMAP0, GX_COLOR0A0);

    GX_ClearVtxDesc();
    GX_SetVtxDesc(GX_VA_POS, GX_DIRECT);
    GX_SetVtxDesc(GX_VA_CLR0, GX_DIRECT);
    GX_SetVtxDesc(GX_VA_TEX0, GX_DIRECT);

    GX_SetTexCoordGen(GX_TEXCOORD0, GX_TG_MTX2x4, GX_TG_TEX0, GX_IDENTITY);

    // Background polygon handling
    u32 param_base = PARAM_BASE & 0xF00000;
    ISP_BACKGND_D_type bg_d;
    ISP_BACKGND_T_type bg_t;

    bg_d.i = ISP_BACKGND_D & ~(0xF);
    bg_t.full = ISP_BACKGND_T;

    bool PSVM = FPU_SHAD_SCALE & 0x100; // Double parameters for volumes

    // Get the strip base
    u32 strip_base = param_base + bg_t.tag_address * 4;
    // Calculate the vertex size
    u32 strip_vs = 3 + bg_t.skip;
    u32 strip_vert_num = bg_t.tag_offset;

    if (PSVM && bg_t.shadow) {
        strip_vs += bg_t.skip; // 2x the size needed
    }
    strip_vs *= 4;
    
    // Get vertex ptr
    u32 vertex_ptr = strip_vert_num * strip_vs + strip_base + 3 * 4;

    Vertex BGTest;
    decode_pvr_vertex(strip_base, vertex_ptr, &BGTest);

    GX_SetCopyClear((GXColor&)BGTest.col, 0x00000000);

    GX_SetZMode(GX_TRUE, GX_GEQUAL, GX_TRUE);
    GX_SetBlendMode(GX_BM_NONE, GX_BL_SRCALPHA, GX_BL_INVSRCALPHA, GX_LO_CLEAR);
    GX_SetAlphaUpdate(GX_TRUE);
    GX_SetColorUpdate(GX_TRUE);

    // Sanitize depth values
    if (vtx_min_Z <= 0.001f)
        vtx_min_Z = 0.001f;
    if (vtx_max_Z < 0 || vtx_max_Z > 128 * 1024)
        vtx_max_Z = 1;

    // Extend range
    vtx_max_Z *= 1.001f; // To not clip vtx_max verts

    // Convert to projection parameters
    float p6 = -1 / (1 / vtx_max_Z - 1 / vtx_min_Z);
    float p5 = p6 / vtx_min_Z;

    Mtx44 projection;
    guOrtho(projection, 
            0, dc_height,  // Changed from centered to 0-based
            0, dc_width,   // Changed from centered to 0-based
            p5, p6);
    GX_LoadProjectionMtx(projection, GX_ORTHOGRAPHIC);

    // Render geometry
    Vertex* drawVTX = vertices;
    VertexList* drawLST = lists;
    VertexList* crLST = curLST;
    PolyParam* drawMod = listModes;

    GX_SetTevOp(GX_TEVSTAGE0, GX_MODULATE);
    GX_SetTevOrder(GX_TEVSTAGE0, GX_TEXCOORD0, GX_TEXMAP0, GX_COLOR0A0);

    for (; drawLST != crLST; drawLST++) {
        if (drawLST == TransLST) {
            // Enable blending for translucent polygons
            GX_SetBlendMode(GX_BM_BLEND, GX_BL_SRCALPHA, GX_BL_INVSRCALPHA, GX_LO_CLEAR);
        }

        s32 count = drawLST->count;
        if (count < 0) {
            if (drawMod->pcw.Texture) {
                // TODO: SetTextureParams(drawMod);
                // For now, just skip textured rendering
                GX_SetTevOp(GX_TEVSTAGE0, GX_PASSCLR);
            } else {
                GX_SetTevOp(GX_TEVSTAGE0, GX_PASSCLR);
            }
            
            drawMod++;
            count &= 0x7FFF;
        }

        if (count) {
            GX_Begin(GX_TRIANGLESTRIP, GX_VTXFMT0, count);
            while (count--) {
                GX_Position3f32(drawVTX->x, drawVTX->y, -drawVTX->z);
                // Swap color bytes for GX (RGBA vs ABGR)
                u32 color = drawVTX->col;
                u32 gx_color = (color & 0xFF00FF00) | ((color >> 16) & 0xFF) | ((color & 0xFF) << 16);
                GX_Color1u32(gx_color);
                GX_TexCoord2f32(drawVTX->u, drawVTX->v);
                drawVTX++;
            }
            GX_End();
        }
    }

    reset_vtx_state();

    static int fb = 1;
    GX_DrawDone();
    GX_CopyDisp(frameBuffer[fb], GX_TRUE);
    VIDEO_SetNextFramebuffer(frameBuffer[fb]);
    VIDEO_Flush();
}

// =============================================================================
// Vertex Decoder Implementation
// =============================================================================

/**
 * @brief Vertex decoder for tile accelerator
 * Processes PVR display list commands and converts to GX-compatible format
 */
struct VertexDecoder {
    // Vertex conversion macros
    #define vert_cvt_base \
        vert_base(0, vtx->xyz[0], vtx->xyz[1], vtx->xyz[2])

    #define vert_base(idx, _x, _y, _z) \
        { \
        float W_##idx = 1.0f / _z; \
        curVTX[idx].x = VTX_TFX(_x) * W_##idx; \
        curVTX[idx].y = VTX_TFY(_y) * W_##idx; \
        curVTX[idx].z = W_##idx; \
        if (W_##idx < vtx_min_Z) vtx_min_Z = W_##idx; \
        else if (W_##idx > vtx_max_Z) vtx_max_Z = W_##idx; \
        }

    #define INTESITY(inte) INTESITY_impl(inte)

    static u32 INTESITY_impl(float inte) {
        u32 C = inte * 255;
        if (C > 255) C = 255;
        return (0xFF << 24) | (C << 16) | (C << 8) | (C);
    }

    #define FLCOL(col) FLCOL_impl(col)

    static u32 FLCOL_impl(float* col) {
        u32 A = col[0] * 255;
        u32 R = col[1] * 255;
        u32 G = col[2] * 255;
        u32 B = col[3] * 255;
        if (A > 255) A = 255;
        if (R > 255) R = 255;
        if (G > 255) G = 255;
        if (B > 255) B = 255;
        return (A << 24) | (B << 16) | (G << 8) | R;
    }

    #define glob_param_bdc \
        if ((curVTX - vertices) > 38 * 1024) reset_vtx_state(); \
        if (!global_regd) curMod++; \
        global_regd = true; \
        curMod->pcw = pp->pcw; \
        curMod->isp = pp->isp; \
        curMod->tsp = pp->tsp; \
        curMod->tcw = pp->tcw;

    // Polygon strip handling
    __forceinline static void StartPolyStrip() {
        curLST->ptr = curVTX;
    }

    __forceinline static void EndPolyStrip() {
        curLST->count = (curVTX - curLST->ptr);
        if (global_regd) {
            curLST->count |= 0x80000000;
            global_regd = false;
        }
        curLST++;
    }

    // Polygon parameter handlers
    __forceinline static void fastcall AppendPolyParam0(TA_PolyParam0* pp) {
        glob_param_bdc;
    }

    __forceinline static void fastcall AppendPolyParam1(TA_PolyParam1* pp) {
        glob_param_bdc;
    }

    __forceinline static void fastcall AppendPolyParam2A(TA_PolyParam2A* pp) {
        glob_param_bdc;
    }

    __forceinline static void fastcall AppendPolyParam2B(TA_PolyParam2B* pp) {
        // No-op
    }

    __forceinline static void fastcall AppendPolyParam3(TA_PolyParam3* pp) {
        glob_param_bdc;
    }

    __forceinline static void fastcall AppendPolyParam4A(TA_PolyParam4A* pp) {
        glob_param_bdc;
    }

    __forceinline static void fastcall AppendPolyParam4B(TA_PolyParam4B* pp) {
        // No-op
    }

    // Vertex type handlers (Non-Textured, Packed Color)
    __forceinline static void AppendPolyVertex0(TA_Vertex0* vtx) {
        vert_cvt_base;
        curVTX->col = ABGR8888(vtx->BaseCol);
        curVTX++;
    }

    // Vertex type handlers (Non-Textured, Floating Color)
    __forceinline static void AppendPolyVertex1(TA_Vertex1* vtx) {
        vert_cvt_base;
        curVTX->col = FLCOL(&vtx->BaseA);
        curVTX++;
    }

    // Vertex type handlers (Non-Textured, Intensity)
    __forceinline static void AppendPolyVertex2(TA_Vertex2* vtx) {
        vert_cvt_base;
        curVTX->col = INTESITY(vtx->BaseInt);
        curVTX++;
    }

    // Vertex type handlers (Textured, Packed Color)
    __forceinline static void AppendPolyVertex3(TA_Vertex3* vtx) {
        vert_cvt_base;
        curVTX->col = ABGR8888(vtx->BaseCol);
        curVTX->u = vtx->u;
        curVTX->v = vtx->v;
        curVTX++;
    }

    // Vertex type handlers (Textured, Packed Color, 16bit UV)
    __forceinline static void AppendPolyVertex4(TA_Vertex4* vtx) {
        vert_cvt_base;
        curVTX->col = ABGR8888(vtx->BaseCol);
        curVTX->u = CVT16UV(vtx->u);
        curVTX->v = CVT16UV(vtx->v);
        curVTX++;
    }

    // Vertex type handlers (Textured, Floating Color) - 64bit
    __forceinline static void AppendPolyVertex5A(TA_Vertex5A* vtx) {
        vert_cvt_base;
        curVTX->u = vtx->u;
        curVTX->v = vtx->v;
    }

    __forceinline static void AppendPolyVertex5B(TA_Vertex5B* vtx) {
        curVTX->col = FLCOL(&vtx->BaseA);
        curVTX++;
    }

    // Vertex type handlers (Textured, Floating Color, 16bit UV) - 64bit
    __forceinline static void AppendPolyVertex6A(TA_Vertex6A* vtx) {
        vert_cvt_base;
        curVTX->u = CVT16UV(vtx->u);
        curVTX->v = CVT16UV(vtx->v);
    }

    __forceinline static void AppendPolyVertex6B(TA_Vertex6B* vtx) {
        curVTX->col = FLCOL(&vtx->BaseA);
        curVTX++;
    }

    // Vertex type handlers (Textured, Intensity)
    __forceinline static void AppendPolyVertex7(TA_Vertex7* vtx) {
        vert_cvt_base;
        curVTX->u = vtx->u;
        curVTX->v = vtx->v;
        curVTX->col = INTESITY(vtx->BaseInt);
        curVTX++;
    }

    // Vertex type handlers (Textured, Intensity, 16bit UV)
    __forceinline static void AppendPolyVertex8(TA_Vertex8* vtx) {
        vert_cvt_base;
        curVTX->u = CVT16UV(vtx->u);
        curVTX->v = CVT16UV(vtx->v);
        curVTX->col = INTESITY(vtx->BaseInt);
        curVTX++;
    }

    // Vertex type handlers (Non-Textured, Packed Color, with Two Volumes)
    __forceinline static void AppendPolyVertex9(TA_Vertex9* vtx) {
        vert_cvt_base;
        curVTX->col = ABGR8888(vtx->BaseCol0);
        curVTX++;
    }

    // Vertex type handlers (Non-Textured, Intensity, with Two Volumes)
    __forceinline static void AppendPolyVertex10(TA_Vertex10* vtx) {
        vert_cvt_base;
        curVTX->col = INTESITY(vtx->BaseInt0);
        curVTX++;
    }

    // Vertex type handlers (Textured, Packed Color, with Two Volumes) - 64bit
    __forceinline static void AppendPolyVertex11A(TA_Vertex11A* vtx) {
        vert_cvt_base;
        curVTX->u = vtx->u0;
        curVTX->v = vtx->v0;
        curVTX->col = ABGR8888(vtx->BaseCol0);
    }

    __forceinline static void AppendPolyVertex11B(TA_Vertex11B* vtx) {
        curVTX++;
    }

    // Vertex type handlers (Textured, Packed Color, 16bit UV, with Two Volumes) - 64bit
    __forceinline static void AppendPolyVertex12A(TA_Vertex12A* vtx) {
        vert_cvt_base;
        curVTX->u = CVT16UV(vtx->u0);
        curVTX->v = CVT16UV(vtx->v0);
        curVTX->col = ABGR8888(vtx->BaseCol0);
    }

    __forceinline static void AppendPolyVertex12B(TA_Vertex12B* vtx) {
        curVTX++;
    }

    // Vertex type handlers (Textured, Intensity, with Two Volumes) - 64bit
    __forceinline static void AppendPolyVertex13A(TA_Vertex13A* vtx) {
        vert_cvt_base;
        curVTX->u = vtx->u0;
        curVTX->v = vtx->v0;
        curVTX->col = INTESITY(vtx->BaseInt0);
    }

    __forceinline static void AppendPolyVertex13B(TA_Vertex13B* vtx) {
        curVTX++;
    }

    // Vertex type handlers (Textured, Intensity, 16bit UV, with Two Volumes) - 64bit
    __forceinline static void AppendPolyVertex14A(TA_Vertex14A* vtx) {
        vert_cvt_base;
        curVTX->u = CVT16UV(vtx->u0);
        curVTX->v = CVT16UV(vtx->v0);
        curVTX->col = INTESITY(vtx->BaseInt0);
    }

    __forceinline static void AppendPolyVertex14B(TA_Vertex14B* vtx) {
        curVTX++;
    }

    // Sprite handlers
    __forceinline static void AppendSpriteParam(TA_SpriteParam* spr) {
        TA_SpriteParam* pp = spr;
        glob_param_bdc;
    }

    #define sprite_uv(indx, u_name, v_name) \
        curVTX[indx].u = CVT16UV(sv->u_name); \
        curVTX[indx].v = CVT16UV(sv->v_name);

    __forceinline static void AppendSpriteVertexA(TA_Sprite1A* sv) {
        StartPolyStrip();
        curVTX[0].col = 0xFFFFFFFF;
        curVTX[1].col = 0xFFFFFFFF;
        curVTX[2].col = 0xFFFFFFFF;
        curVTX[3].col = 0xFFFFFFFF;

        vert_base(2, sv->x0, sv->y0, sv->z0);
        vert_base(3, sv->x1, sv->y1, sv->z1);
        curVTX[1].x = sv->x2;
    }

    __forceinline static void AppendSpriteVertexB(TA_Sprite1B* sv) {
        vert_base(1, curVTX[1].x, sv->y2, sv->z2);
        vert_base(0, sv->x3, sv->y3, sv->z2);

        sprite_uv(2, u0, v0);
        sprite_uv(3, u1, v1);
        sprite_uv(1, u2, v2);
        sprite_uv(0, u0, v2);

        curVTX += 4;

        curLST->count = 4;
        if (global_regd) {
            curLST->count |= 0x80000000;
            global_regd = false;
        }
        curLST++;
    }

    // Modifier volume handlers (stubs for now)
    __forceinline static void AppendModVolParam(TA_ModVolParam* modv) {
        // TODO: Implement modifier volumes
    }

    __forceinline static void StartModVol(TA_ModVolParam* param) {
        // TODO: Implement modifier volumes
    }

    __forceinline static void ModVolStripEnd() {
        // TODO: Implement modifier volumes
    }

    __forceinline static void AppendModVolVertexA(TA_ModVolA* mvv) {
        // TODO: Implement modifier volumes
    }

    __forceinline static void AppendModVolVertexB(TA_ModVolB* mvv) {
        // TODO: Implement modifier volumes
    }

    // Tile clipping
    __forceinline static void SetTileClip(u32 xmin, u32 ymin, u32 xmax, u32 ymax) {
        // TODO: Implement tile clipping
    }

    __forceinline static void TileClipMode(u32 mode) {
        // TODO: Implement tile clip mode
    }

    // List control
    __forceinline static void StartList(u32 ListType) {
        if (ListType == ListType_Translucent)
            TransLST = curLST;
    }

    __forceinline static void EndList(u32 ListType) {
        // No-op
    }

    __forceinline static void ListCont() {
        // Continue list
    }

    __forceinline static void ListInit() {
        // Initialize list
    }

    __forceinline static void SoftReset() {
        // Soft reset
    }
};

// =============================================================================
// Public API Implementation
// =============================================================================

void VBlank() {
    // Handle vertical blank
}

void SetFpsText(char* text) {
    if (text) {
        strncpy(fps_text, text, sizeof(fps_text) - 1);
        fps_text[sizeof(fps_text) - 1] = '\0';
        printf("%s\n", fps_text);
    }
}

bool InitRenderer() {
    // Get preferred video mode from system settings
    rmode = VIDEO_GetPreferredMode(nullptr);
    if (!rmode) {
        printf("ERROR: Failed to get video mode\n");
        return false;
    }

    // Adjust for PAL systems
    switch (rmode->viTVMode >> 2) {
        case VI_NTSC:
            // 480 lines (NTSC 60Hz) - use as-is
            break;
            
        case VI_PAL:
            // 576 lines (PAL 50Hz) - adjust to 480 lines
            rmode = &TVPal576IntDfScale;
            rmode->xfbHeight = 480;
            rmode->viYOrigin = (VI_MAX_HEIGHT_PAL - 480) / 2;
            rmode->viHeight = 480;
            break;
            
        default:
            // 480 lines (PAL 60Hz) - use as-is
            break;
    }

    // Configure video
    VIDEO_Configure(rmode);

    // Allocate framebuffers in uncached memory
    frameBuffer[0] = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));
    frameBuffer[1] = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));
    
    if (!frameBuffer[0] || !frameBuffer[1]) {
        printf("ERROR: Failed to allocate framebuffers\n");
        return false;
    }

    // Set up video
    VIDEO_SetNextFramebuffer(frameBuffer[currentFrameBuffer]);
    VIDEO_SetBlack(TRUE);
    VIDEO_Flush();
    VIDEO_WaitVSync();
    
    if (rmode->viTVMode & VI_NON_INTERLACE) {
        VIDEO_WaitVSync();
    }

    // Flip to other framebuffer
    currentFrameBuffer ^= 1;

    // Initialize GX FIFO
    memset(gp_fifo, 0, DEFAULT_FIFO_SIZE);
    GX_Init(gp_fifo, DEFAULT_FIFO_SIZE);

    // Configure GX viewport
    GX_SetViewport(0, 0, rmode->fbWidth, rmode->efbHeight, 0, 1);
    
    f32 yscale = GX_GetYScaleFactor(rmode->efbHeight, rmode->xfbHeight);
    u32 xfbHeight = GX_SetDispCopyYScale(yscale);
    
    GX_SetScissor(0, 0, rmode->fbWidth, rmode->efbHeight);
    GX_SetDispCopySrc(0, 0, rmode->fbWidth, rmode->efbHeight);
    GX_SetDispCopyDst(rmode->fbWidth, xfbHeight);
    GX_SetCopyFilter(rmode->aa, rmode->sample_pattern, GX_TRUE, rmode->vfilter);
    
    u32 field_mode = (rmode->viHeight == 2 * rmode->xfbHeight) ? GX_ENABLE : GX_DISABLE;
    GX_SetFieldMode(rmode->field_rendering, field_mode);

    // Set pixel format based on AA mode
    if (rmode->aa) {
        GX_SetPixelFmt(GX_PF_RGB565_Z16, GX_ZC_LINEAR);
    } else {
        GX_SetPixelFmt(GX_PF_RGB8_Z24, GX_ZC_LINEAR);
    }

    // Configure rendering state
    GX_SetCullMode(GX_CULL_NONE);
    GX_CopyDisp(frameBuffer[currentFrameBuffer], GX_TRUE);
    GX_SetDispCopyGamma(GX_GM_1_0);

    // Initialize tile accelerator
    if (!TileAccel.Init()) {
        printf("ERROR: Failed to initialize tile accelerator\n");
        return false;
    }

    printf("GX Renderer initialized successfully\n");
    return true;
}

void TermRenderer() {
    TileAccel.Term();
    
    // Free framebuffers
    if (frameBuffer[0]) {
        free(MEM_K1_TO_K0(frameBuffer[0]));
        frameBuffer[0] = nullptr;
    }
    if (frameBuffer[1]) {
        free(MEM_K1_TO_K0(frameBuffer[1]));
        frameBuffer[1] = nullptr;
    }
    
    printf("GX Renderer terminated\n");
}

void ResetRenderer(bool Manual) {
    TileAccel.Reset(Manual);
    VertexCount = 0;
    FrameCount = 0;
    reset_vtx_state();
}

bool ThreadStart() {
    // Single-threaded on Wii, no action needed
    return true;
}

void ThreadEnd() {
    // Single-threaded on Wii, no action needed
}

void StartRender() {
    u32 VtxCnt = curVTX - vertices;
    VertexCount += VtxCnt;

    render_end_pending_cycles = VtxCnt * 15;
    if (render_end_pending_cycles < 50000)
        render_end_pending_cycles = 50000;

    if (FB_W_SOF1 & 0x1000000)
        return;

    DoRender();

    FrameCount++;
}

void EndRender() {
    // No-op in original
}

void ListCont() {
    TileAccel.ListCont();
}

void ListInit() {
    TileAccel.ListInit();
}

void SoftReset() {
    TileAccel.SoftReset();
}

void VramLockedWrite(vram_block* bl) {
    // Handle VRAM write notification
    // TODO: Invalidate affected textures in cache
}

// =============================================================================
// Boot File Helper
// =============================================================================

/**
 * @brief Get boot file path
 * @param szFileName Output buffer for filename
 * @param szParse Optional parse string (unused)
 * @param flags Optional flags (unused)
 * @return 1 if file found, 0 otherwise
 */
int GetFile(char* szFileName, char* szParse = nullptr, u32 flags = 0) {
    if (FILE* f = fopen("/boot.cdi", "rb")) {
        fclose(f);
        strcpy(szFileName, "/boot.cdi");
        return 1;
    }
    return 0;
}

#endif // REND_API == REND_WII || 1

#pragma once

/**
 * @file gxRend.h
 * @brief GX Renderer for Dreamcast emulator on Wii
 * 
 * This renderer uses the Wii's GX graphics library to emulate the Dreamcast's
 * PowerVR graphics hardware. It provides hardware-accelerated rendering using
 * the Wii's fixed-function graphics pipeline.
 * 
 * Architecture Notes:
 * - HLE (High-Level Emulation) renderer with approximate accuracy
 * - Uses GX fixed-function pipeline (driver-dependent behavior)
 * - Danger Zone: Platform-specific quirks may affect compatibility
 */

#include "drkPvr.h"
#include "Renderer_if.h"

#if REND_API == REND_WII

// Forward declarations
struct PolyParam;
struct Vertex;

/**
 * @brief Initialize the GX renderer and video subsystem
 * @return true on success, false on failure
 */
bool InitRenderer();

/**
 * @brief Terminate renderer and free allocated resources
 */
void TermRenderer();

/**
 * @brief Reset renderer state
 * @param Manual true if manual reset requested by user
 */
void ResetRenderer(bool Manual);

/**
 * @brief Start rendering thread (no-op on Wii, single-threaded)
 * @return true on success
 */
bool ThreadStart();

/**
 * @brief End rendering thread (no-op on Wii)
 */
void ThreadEnd();

/**
 * @brief Handle vertical blank interrupt
 * Called during VBlank to synchronize rendering
 */
void VBlank();

/**
 * @brief Begin a new render frame
 * Sets up frame state and prepares for drawing
 */
void StartRender();

/**
 * @brief End current render frame
 * Flushes commands and presents framebuffer
 */
void EndRender();

/**
 * @brief Continue current display list
 */
void ListCont();

/**
 * @brief Initialize display list
 */
void ListInit();

/**
 * @brief Perform soft reset of rendering state
 */
void SoftReset();

/**
 * @brief Set FPS display text
 * @param text FPS string to display
 */
void SetFpsText(char* text);

/**
 * @brief Handle VRAM locked write notification
 * @param bl VRAM block that was written
 */
void VramLockedWrite(vram_block* bl);

// Renderer API macros for platform abstraction
#define rend_init                InitRenderer
#define rend_term                TermRenderer
#define rend_reset               ResetRenderer

#define rend_thread_start        ThreadStart
#define rend_thread_end          ThreadEnd
#define rend_vblank              VBlank
#define rend_start_render        StartRender
#define rend_end_render          EndRender

#define rend_list_cont           ListCont
#define rend_list_init           ListInit
#define rend_list_srst           SoftReset

#define rend_set_fps_text        SetFpsText
#define rend_vramlock_write      VramLockedWrite

// No-op macros for unsupported features on Wii
#define rend_set_render_rect(rect, sht)  do { } while(0)
#define rend_set_fb_scale(x, y)          do { } while(0)

// Configuration constants
namespace GXRendConfig {
    constexpr u32 DEFAULT_FIFO_SIZE = 256 * 1024;
    constexpr u32 MAX_VERTICES = 42 * 1024;
    constexpr u32 MAX_LISTS = 8 * 1024;
    constexpr float DEFAULT_MIN_Z = 128.0f * 1024.0f;
    constexpr float DEFAULT_MAX_Z = 0.0f;
}

#endif // REND_API == REND_WII
